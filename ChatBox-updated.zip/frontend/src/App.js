import React from "react";
import ChatBox from "./components/ChatBox/ChatBox";
import "./App.css";

function App() {
  return <ChatBox />;
}

export default App;
