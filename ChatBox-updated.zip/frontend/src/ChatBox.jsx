// Legacy file kept to maintain structure; now re-exports the main ChatBox
export { default } from "./components/ChatBox/ChatBox";
